package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Scaffold: poe blocos automaticamente embaixo dos seus pes enquanto voce anda,
 * para voce atravessar vazio, rios ou lava sem parar. Usa os blocos da hotbar
 * (ignora blocos que caem, como areia, e blocos com inventario, como baus).
 *
 * Como funciona a cada tick:
 *  1. calcula a posicao embaixo de voce, um pouco a frente (pela sua velocidade);
 *  2. se ela esta vazia, acha um bloco solido vizinho para apoiar a colocacao;
 *  3. troca para um bloco da hotbar e coloca, com a mira silenciosa (a camera
 *     nao se mexe);
 *  4. ao desligar, devolve o slot que voce estava usando.
 */
public class Scaffold extends Module {
    private int originalSlot = -1;

    public Scaffold() {
        super("Scaffold", Category.WORLD);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onEnable() { originalSlot = -1; }

    @Override
    public void onDisable() {
        if (mc.player != null && originalSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        originalSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.currentScreen != null) return;

        int slot = findBlockSlot();
        if (slot == -1) return;

        // posicao embaixo dos pes, levemente a frente pela velocidade
        Vec3d vel = mc.player.getVelocity();
        BlockPos below = BlockPos.ofFloored(
                mc.player.getX() + vel.x * 2.0,
                mc.player.getY() - 1.0,
                mc.player.getZ() + vel.z * 2.0);

        // tenta o bloco embaixo; se nao tiver apoio, tenta os vizinhos horizontais
        BlockPos[] candidates = {below, below.north(), below.south(), below.east(), below.west()};
        for (BlockPos target : candidates) {
            if (!mc.world.getBlockState(target).isReplaceable()) continue;
            Direction face = findSupportFace(target);
            if (face == null) continue;
            place(target, face, slot);
            return; // um bloco por tick
        }
    }

    /** Acha o lado de um bloco vizinho solido onde da para clicar para colocar em `target`. */
    private Direction findSupportFace(BlockPos target) {
        for (Direction d : Direction.values()) {
            BlockPos support = target.offset(d);
            BlockState st = mc.world.getBlockState(support);
            if (!st.isAir() && !st.isReplaceable()) {
                return d.getOpposite(); // face do apoio que aponta para `target`
            }
        }
        return null;
    }

    private void place(BlockPos target, Direction faceOfSupport, int slot) {
        BlockPos support = target.offset(faceOfSupport.getOpposite());
        Vec3d hit = Vec3d.ofCenter(support).add(new Vec3d(
                faceOfSupport.getOffsetX(), faceOfSupport.getOffsetY(), faceOfSupport.getOffsetZ()).multiply(0.5));

        if (originalSlot < 0) originalSlot = mc.player.getInventory().getSelectedSlot();
        if (mc.player.getInventory().getSelectedSlot() != slot) {
            mc.player.getInventory().setSelectedSlot(slot);
        }

        // mira silenciosa: olha para o ponto, coloca e devolve a mira real
        var net = mc.getNetworkHandler();
        if (net != null) {
            Vec3d eye = mc.player.getEyePos();
            double dx = hit.x - eye.x, dy = hit.y - eye.y, dz = hit.z - eye.z;
            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch,
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                new BlockHitResult(hit, faceOfSupport, support, false));
        mc.player.swingHand(Hand.MAIN_HAND);

        if (net != null) {
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(mc.player.getYaw(), mc.player.getPitch(),
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }
    }

    /** Primeiro bloco solido "comum" da hotbar (sem blocos que caem nem com inventario). */
    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem bi)) continue;
            Block block = bi.getBlock();
            if (block instanceof FallingBlock || block instanceof BlockEntityProvider) continue;
            if (!block.getDefaultState().isSolidBlock(mc.world, BlockPos.ORIGIN)) continue;
            return i;
        }
        return -1;
    }
}
