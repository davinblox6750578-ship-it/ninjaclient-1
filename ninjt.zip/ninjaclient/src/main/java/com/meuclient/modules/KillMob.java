package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/**
 * KillMob: mata os mobs que estiverem no alcance, hostis e passivos.
 * Alcance: o do jogo (3 blocos) + 1 bloco extra = 4 blocos.
 * NAO ataca: zombie piglin, cachorro (lobo), aldeao (e vendedor ambulante),
 * cavalo (e burro, mula, lhama, camelo) e gato.
 * Golem de ferro: so ataca se estiver BRAVO com voce (ver updateGolems),
 * em qualquer posicao, inclusive atras de voce (a mira silenciosa vira para ele).
 * Ataca com a barra de cooldown em 90%, mesmo com o mob atras de blocos.
 */
public class KillMob extends Module {
    private static final double RANGE = 3.0 + 1.0; // alcance normal + 1 bloco
    private static final float MIN_COOLDOWN = 0.90f;
    private static final int ANGRY_MEMORY_TICKS = 60; // lembra que o golem esta bravo por 3 s
    private static final int CHASE_STREAK = 4;        // ticks seguidos vindo na sua direcao

    private int tickCount;
    private final Map<Integer, Vec3d> lastPos = new HashMap<>();
    private final Map<Integer, Integer> chaseStreak = new HashMap<>();
    private final Map<Integer, Integer> angryUntil = new HashMap<>();

    public KillMob() {
        super("KillMob", Category.WORLD);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        lastPos.clear();
        chaseStreak.clear();
        angryUntil.clear();
    }

    @Override
    public void onTick() {
        tickCount++;
        updateGolems();

        if (mc.currentScreen != null || !Combat.cooldownReady(mc, MIN_COOLDOWN)) return;

        Entity best = null;
        double bestDist = RANGE;
        for (Entity e : mc.world.getEntities()) {
            if (!isTarget(e)) continue;
            double d = mc.player.distanceTo(e);
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        if (best != null) Combat.silentAttack(mc, best);
    }

    /**
     * O servidor nao envia ao client se o golem esta bravo, entao detectamos por sinais:
     *  - ele fez a animacao de ataque (bracos levantados); ou
     *  - ele vem andando na SUA direcao, de perto, por alguns ticks seguidos.
     * Quando um sinal aparece, o golem fica marcado como bravo por 3 segundos.
     * E uma estimativa: pode errar se um golem passar andando na sua direcao.
     */
    private void updateGolems() {
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof IronGolemEntity golem) || !golem.isAlive()) continue;
            int id = golem.getId();
            Vec3d pos = golem.getPos();
            Vec3d last = lastPos.put(id, pos);

            boolean attacking = golem.getAttackTicksLeft() > 0;

            boolean approaching = false;
            if (last != null) {
                Vec3d move = new Vec3d(pos.x - last.x, 0, pos.z - last.z);
                Vec3d toMe = new Vec3d(mc.player.getX() - pos.x, 0, mc.player.getZ() - pos.z);
                if (move.length() > 0.05 && toMe.length() < 10.0) {
                    approaching = move.normalize().dotProduct(toMe.normalize()) > 0.8;
                }
            }
            int streak = approaching ? chaseStreak.getOrDefault(id, 0) + 1 : 0;
            chaseStreak.put(id, streak);

            if (attacking || streak >= CHASE_STREAK) {
                angryUntil.put(id, tickCount + ANGRY_MEMORY_TICKS);
            }
        }
    }

    private boolean isTarget(Entity e) {
        if (!(e instanceof MobEntity mob) || !mob.isAlive()) return false;

        // golem de ferro: so se estiver bravo
        if (e instanceof IronGolemEntity golem) {
            return angryUntil.getOrDefault(golem.getId(), 0) > tickCount;
        }

        // excecoes: mobs que nao devem ser mortos
        return !(e instanceof ZombifiedPiglinEntity
                || e instanceof WolfEntity
                || e instanceof VillagerEntity
                || e instanceof WanderingTraderEntity
                || e instanceof AbstractHorseEntity
                || e instanceof CatEntity);
    }
}
