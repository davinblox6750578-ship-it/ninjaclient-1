package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import com.meuclient.MeuClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * ESP de vida: mostra a vida de cada jogador em cima da cabeca, em coracoes
 * (ex.: "10 ❤"). Atualiza todo frame, entao quando ele leva dano o numero
 * cai na hora. Vida extra (maca dourada) aparece em dourado, ex.: "10 +2 ❤".
 * Cor: verde = vida boa, amarelo = media, vermelho = baixa.
 */
public class ESPVida extends Module {
    private static boolean registered;

    public ESPVida() {
        super("ESPVida", Category.PLAYER);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        if (!registered) {
            registered = true;
            HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                    Identifier.of("ninjaclient", "espvida"), (ctx, tickCounter) -> render(ctx));
        }
    }

    private void render(DrawContext ctx) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        float delta = mc.getRenderTickCounter().getTickProgress(false);
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) sw / sh;

        // se o BoxESP estiver ligado, sobe mais para nao cobrir o nome dele
        Module box = MeuClient.modules.get("BoxESP");
        int lift = (box != null && box.isEnabled()) ? 24 : 12;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.player || !p.isAlive() || p.isSpectator()) continue;

            Vec3d pos = p.getLerpedPos(delta);
            Vec3d head = new Vec3d(pos.x, pos.y + p.getHeight(), pos.z);
            Vec3d d = head.subtract(camPos);
            double z = d.dotProduct(fwd);
            if (z <= 0.05) continue; // atras da camera

            int sx = (int) (sw / 2.0 + (d.dotProduct(right) / z) / (tanHalf * aspect) * (sw / 2.0));
            int sy = (int) (sh / 2.0 - (d.dotProduct(up) / z) / tanHalf * (sh / 2.0));

            float health = p.getHealth();
            float max = Math.max(1f, p.getMaxHealth());
            float absorption = p.getAbsorptionAmount();

            int color = health / max > 0.6f ? 0xFF55FF55 : health / max > 0.3f ? 0xFFFFFF55 : 0xFFFF5555;

            String hearts = fmt(health / 2f);
            String extra = absorption > 0 ? " +" + fmt(absorption / 2f) : "";
            String main = hearts + extra + " ";
            String heart = "\u2764";

            int totalW = mc.textRenderer.getWidth(main + heart);
            int tx = sx - totalW / 2, ty = sy - lift;
            ctx.drawText(mc.textRenderer, hearts, tx, ty, color, true);
            int cx = tx + mc.textRenderer.getWidth(hearts);
            if (absorption > 0) {
                ctx.drawText(mc.textRenderer, extra, cx, ty, 0xFFFFAA00, true);
                cx += mc.textRenderer.getWidth(extra);
            }
            ctx.drawText(mc.textRenderer, " " + heart, cx, ty, 0xFFFF3030, true);
        }
    }

    /** 10.0 -> "10", 9.5 -> "9.5" */
    private static String fmt(float v) {
        float r = Math.round(v * 2f) / 2f; // arredonda para meio coracao
        return r == (int) r ? String.valueOf((int) r) : String.valueOf(r);
    }
}
