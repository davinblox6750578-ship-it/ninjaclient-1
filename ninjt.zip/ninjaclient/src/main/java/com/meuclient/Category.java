package com.meuclient;

public enum Category {
    COMBAT("Combat"), MOVEMENT("Movement"), PLAYER("Player"),
    RENDER("Render"), WORLD("World"), MISC("Misc");

    public final String label;
    Category(String label) { this.label = label; }
}
